<?php

use Illuminate\Database\Seeder;
use App\Comment;

class CommentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $faker = Faker\Factory::create();

        foreach(range(1,20) as $i)
        {
            Comment::create([
                'author' => $faker->name,
                'text'   => $faker->text,
            ]);
        }
    }
}
